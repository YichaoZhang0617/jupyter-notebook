import numpy as np
import matplotlib.pyplot as plt
import scipy.io
from scipy.fftpack import fft

r = 'E:\\python项目（公司）\\jupyter notebook\\Bearing Data\\Normal Baseline Data\\97.mat'
data = scipy.io.loadmat(r)

x1 = data['X097_DE_time']
x1 = x1.tolist()
plt.subplot(2,2,1)
plt.plot(x1)
plt.title('X097_DE_time Row Data')

N = len(x1)
k = []
for j in x1:
    kk = float(j[0])
    k.append(kk)
y1 = fft(k, N)
mag = abs(y1)

sampleRate = 12000
f = []
for i in range(N):
    ff = i * sampleRate / N
    f.append(ff)
xx1 = np.array(f)
yy1 = np.array(mag)

x = xx1[range(int(N / 2))]
y = yy1[range(int(N / 2))]
plt.subplot(2,2,2)
plt.plot(x,y)
plt.title('X097_DE_time FFT Data')

x2 = data['X097_FE_time']
x2 = x2.tolist()
plt.subplot(2,2,3)
plt.plot(x2)
plt.title('X097_FE_time Row Data')

N = len(x2)
k = []
for j in x2:
    kk = float(j[0])
    k.append(kk)
y2 = fft(k, N)
mag = abs(y2)

sampleRate = 12000
f = []
for i in range(N):
    ff = i * sampleRate / N
    f.append(ff)
xx2 = np.array(f)
yy2 = np.array(mag)

x = xx2[range(int(N / 2))]
y = yy2[range(int(N / 2))]
plt.subplot(2,2,4)
plt.plot(x,y)
plt.title('X097_FE_time FFT Data')
plt.show()